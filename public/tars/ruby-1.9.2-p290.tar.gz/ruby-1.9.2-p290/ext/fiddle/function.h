#ifndef FIDDLE_FUNCTION_H
#define FIDDLE_FUNCTION_H

#include <fiddle.h>

void Init_fiddle_function();

#endif
