extern void nurat_canonicalization(int);

void
Init_rational(void)
{
    nurat_canonicalization(1);
}
