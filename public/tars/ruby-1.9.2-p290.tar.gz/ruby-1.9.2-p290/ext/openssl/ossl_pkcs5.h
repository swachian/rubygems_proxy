#if !defined(_OSSL_PKCS5_H_)
#define _OSSL_PKCS5_H_

void Init_ossl_pkcs5(void);

#endif /* _OSSL_PKCS5_H_ */
